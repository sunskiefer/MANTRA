<?xml version="1.0" encoding="UTF-8"?>

<pluginstate>
  <version file="1" date="2026-11-14-18-07"/>
  <PLUGIN name="MANTRA" descriptiveName="MANTRA" format="VST" category="Effect" manufacturer="L'Cronx"
          version="1.0" file="%payload-path%/L'Cronx - VST - MANTRA/mantra.so" uid="4d6e7472" isInstrument="0" fileTime="0"
          infoUpdateTime="0" numInputs="2" numOutputs="2" isShell="0"/>
  <preset>Default</preset>
  <state>161.CMlaKA....fQBMDZ....AzjazIG....x....A...............................................................................................................................................................................A..</state>
</pluginstate>
